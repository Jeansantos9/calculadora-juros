import React, { useState } from 'react';
import { InputParams, CalculationResult, AdvisorStatus } from '../types';
import { generateFinancialAdvice } from '../services/geminiService';
import { Sparkles, Loader2, AlertCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface GeminiAdvisorProps {
  inputs: InputParams;
  result: CalculationResult;
}

const GeminiAdvisor: React.FC<GeminiAdvisorProps> = ({ inputs, result }) => {
  const [status, setStatus] = useState<AdvisorStatus>(AdvisorStatus.IDLE);
  const [advice, setAdvice] = useState<string>('');

  const handleGetAdvice = async () => {
    setStatus(AdvisorStatus.LOADING);
    const text = await generateFinancialAdvice(inputs, result);
    setAdvice(text);
    setStatus(AdvisorStatus.SUCCESS);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-2xl shadow-sm border border-indigo-100 mt-6">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-indigo-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-600" />
          IA Advisor
        </h3>
        
        {status === AdvisorStatus.IDLE || status === AdvisorStatus.SUCCESS ? (
          <button
            onClick={handleGetAdvice}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-all flex items-center gap-2 shadow-sm hover:shadow-md active:scale-95"
          >
            {status === AdvisorStatus.SUCCESS ? 'Gerar Nova Análise' : 'Analisar Cenário'}
          </button>
        ) : (
           <div className="px-4 py-2 bg-indigo-200 text-indigo-700 text-sm font-medium rounded-lg flex items-center gap-2 cursor-wait">
             <Loader2 className="w-4 h-4 animate-spin" />
             Analisando...
           </div>
        )}
      </div>

      {status === AdvisorStatus.IDLE && (
        <p className="text-indigo-800/70 text-sm">
          Use nossa inteligência artificial para receber insights personalizados sobre seu investimento e dicas para otimizar seus rendimentos.
        </p>
      )}

      {status === AdvisorStatus.SUCCESS && (
        <div className="prose prose-sm prose-indigo max-w-none text-slate-700 bg-white/60 p-4 rounded-xl border border-indigo-100/50">
          <ReactMarkdown>{advice}</ReactMarkdown>
        </div>
      )}
      
      {status === AdvisorStatus.ERROR && (
         <div className="text-red-500 text-sm flex items-center gap-2 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-4 h-4" />
            Não foi possível conectar ao consultor.
         </div>
      )}
    </div>
  );
};

export default GeminiAdvisor;