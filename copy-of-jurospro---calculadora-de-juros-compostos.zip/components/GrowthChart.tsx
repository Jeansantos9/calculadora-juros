import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import { MonthlyData } from '../types';
import { formatCurrency } from '../services/calculatorService';

interface GrowthChartProps {
  data: MonthlyData[];
}

const GrowthChart: React.FC<GrowthChartProps> = ({ data }) => {
  // Downsample data if too large for performance and clarity
  const chartData = React.useMemo(() => {
    if (data.length <= 60) return data;
    // Show approx 60 points max
    const step = Math.ceil(data.length / 60);
    return data.filter((_, index) => index % step === 0 || index === data.length - 1);
  }, [data]);

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 h-[400px]">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Evolução Patrimonial</h3>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={chartData}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <defs>
            <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="colorInvested" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#64748b" stopOpacity={0.2}/>
              <stop offset="95%" stopColor="#64748b" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
          <XAxis 
            dataKey="month" 
            tickFormatter={(value) => {
                const year = Math.floor(value / 12);
                return year > 0 && value % 12 === 0 ? `${year}a` : '';
            }}
            stroke="#94a3b8"
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            tickFormatter={(value) => {
                if(value >= 1000000) return `${(value/1000000).toFixed(1)}M`;
                if(value >= 1000) return `${(value/1000).toFixed(0)}k`;
                return value;
            }}
            stroke="#94a3b8"
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip 
            formatter={(value: number) => [formatCurrency(value), ""]}
            labelFormatter={(label) => {
                const years = Math.floor(Number(label) / 12);
                const months = Number(label) % 12;
                return `${years} anos e ${months} meses`;
            }}
            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }}/>
          <Area 
            type="monotone" 
            dataKey="total" 
            name="Valor Total"
            stroke="#10b981" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorTotal)" 
          />
          <Area 
            type="monotone" 
            dataKey="invested" 
            name="Total Investido"
            stroke="#64748b" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorInvested)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default GrowthChart;