import React from 'react';
import { InputParams } from '../types';
import { DollarSign, Calendar, Percent, PiggyBank } from 'lucide-react';

interface InputCardProps {
  inputs: InputParams;
  setInputs: React.Dispatch<React.SetStateAction<InputParams>>;
}

const InputCard: React.FC<InputCardProps> = ({ inputs, setInputs }) => {
  
  const handleChange = (field: keyof InputParams, value: number | string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
      <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center gap-2">
        <PiggyBank className="w-5 h-5 text-emerald-600" />
        Parâmetros
      </h2>

      <div className="space-y-6">
        {/* Initial Principal */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Valor Inicial (R$)</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-slate-400">R$</span>
            </div>
            <input
              type="number"
              min="0"
              value={inputs.initialPrincipal}
              onChange={(e) => handleChange('initialPrincipal', Number(e.target.value))}
              className="pl-10 block w-full rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 transition-colors"
            />
          </div>
        </div>

        {/* Monthly Contribution */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Aporte Mensal (R$)</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <DollarSign className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="number"
              min="0"
              value={inputs.monthlyContribution}
              onChange={(e) => handleChange('monthlyContribution', Number(e.target.value))}
              className="pl-10 block w-full rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 transition-colors"
            />
          </div>
        </div>

        {/* Interest Rate */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Taxa de Juros (%)</label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Percent className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="number"
                min="0"
                step="0.1"
                value={inputs.interestRate}
                onChange={(e) => handleChange('interestRate', Number(e.target.value))}
                className="pl-10 block w-full rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 transition-colors"
              />
            </div>
            <select
              value={inputs.rateFrequency}
              onChange={(e) => handleChange('rateFrequency', e.target.value)}
              className="block w-28 rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 px-2"
            >
              <option value="yearly">Anual</option>
              <option value="monthly">Mensal</option>
            </select>
          </div>
        </div>

        {/* Time Period */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Período</label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="number"
                min="1"
                value={inputs.timePeriod}
                onChange={(e) => handleChange('timePeriod', Number(e.target.value))}
                className="pl-10 block w-full rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 transition-colors"
              />
            </div>
            <select
              value={inputs.periodUnit}
              onChange={(e) => handleChange('periodUnit', e.target.value)}
              className="block w-28 rounded-lg border-slate-200 bg-slate-50 border focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm py-2.5 px-2"
            >
              <option value="years">Anos</option>
              <option value="months">Meses</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InputCard;