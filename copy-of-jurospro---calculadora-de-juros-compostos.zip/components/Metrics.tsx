import React from 'react';
import { CalculationResult } from '../types';
import { formatCurrency } from '../services/calculatorService';
import { TrendingUp, Wallet, Coins } from 'lucide-react';

interface MetricsProps {
  result: CalculationResult;
}

const Metrics: React.FC<MetricsProps> = ({ result }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div className="flex items-center gap-2 mb-2">
            <div className="p-2 bg-blue-50 rounded-lg">
                <Wallet className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-sm font-medium text-slate-500">Total Investido</span>
        </div>
        <span className="text-2xl font-bold text-slate-800">{formatCurrency(result.totalInvested)}</span>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div className="flex items-center gap-2 mb-2">
            <div className="p-2 bg-emerald-50 rounded-lg">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <span className="text-sm font-medium text-slate-500">Total em Juros</span>
        </div>
        <span className="text-2xl font-bold text-emerald-600">{formatCurrency(result.totalInterest)}</span>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-emerald-100/50 to-transparent rounded-bl-full -mr-4 -mt-4" />
        <div className="flex items-center gap-2 mb-2 z-10">
            <div className="p-2 bg-indigo-50 rounded-lg">
                <Coins className="w-5 h-5 text-indigo-600" />
            </div>
            <span className="text-sm font-medium text-slate-500">Valor Final</span>
        </div>
        <span className="text-3xl font-bold text-slate-900 z-10">{formatCurrency(result.finalAmount)}</span>
      </div>
    </div>
  );
};

export default Metrics;