import { GoogleGenAI } from "@google/genai";
import { InputParams, CalculationResult } from "../types";
import { formatCurrency } from "./calculatorService";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateFinancialAdvice = async (
  inputs: InputParams,
  results: CalculationResult
): Promise<string> => {
  try {
    const ai = getClient();
    
    // Using flash for faster response on simple text generation
    const modelId = "gemini-2.5-flash";

    const prompt = `
      Atue como um consultor financeiro experiente e encorajador.
      
      Analise o seguinte cenário de investimento de um usuário brasileiro:
      - Investimento Inicial: ${formatCurrency(inputs.initialPrincipal)}
      - Aporte Mensal: ${formatCurrency(inputs.monthlyContribution)}
      - Taxa de Juros: ${inputs.interestRate}% ao ${inputs.rateFrequency === 'yearly' ? 'ano' : 'mês'}
      - Prazo: ${inputs.timePeriod} ${inputs.periodUnit === 'years' ? 'anos' : 'meses'}
      
      Resultados Projetados:
      - Total Investido: ${formatCurrency(results.totalInvested)}
      - Total em Juros (Lucro): ${formatCurrency(results.totalInterest)}
      - Montante Final: ${formatCurrency(results.finalAmount)}
      
      Por favor, forneça:
      1. Uma breve análise se este é um bom retorno.
      2. O poder dos juros compostos neste cenário específico (mencione como o tempo ou a taxa influenciaram).
      3. Uma sugestão prática (ex: se aumentasse o aporte em 10%, ou se conseguisse uma taxa 1% melhor).
      4. Mantenha o tom profissional, mas acessível. Use Markdown para formatação (negrito, listas). Responda em Português do Brasil.
      5. Máximo de 2 parágrafos e 3 bullet points.
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
    });

    return response.text || "Não foi possível gerar uma análise no momento.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Desculpe, ocorreu um erro ao consultar o assistente de IA. Verifique sua chave de API.";
  }
};