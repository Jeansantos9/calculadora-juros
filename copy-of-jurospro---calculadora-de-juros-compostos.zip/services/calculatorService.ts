import { InputParams, CalculationResult, MonthlyData } from '../types';

export const calculateCompoundInterest = (params: InputParams): CalculationResult => {
  const {
    initialPrincipal,
    monthlyContribution,
    interestRate,
    rateFrequency,
    timePeriod,
    periodUnit
  } = params;

  // Normalize time to months
  const totalMonths = periodUnit === 'years' ? timePeriod * 12 : timePeriod;

  // Normalize rate to monthly decimal
  // If yearly, we calculate effective monthly rate: (1 + r)^(1/12) - 1
  // If monthly, simply r / 100
  let monthlyRate = 0;
  if (rateFrequency === 'yearly') {
    monthlyRate = Math.pow(1 + interestRate / 100, 1 / 12) - 1;
  } else {
    monthlyRate = interestRate / 100;
  }

  let currentTotal = initialPrincipal;
  let totalInvested = initialPrincipal;
  const breakdown: MonthlyData[] = [];

  // Add initial state (Month 0)
  breakdown.push({
    month: 0,
    year: 0,
    invested: initialPrincipal,
    interest: 0,
    total: initialPrincipal
  });

  for (let i = 1; i <= totalMonths; i++) {
    // Interest is calculated on the amount at the start of the month
    const interestEarned = currentTotal * monthlyRate;
    
    // Add monthly contribution
    currentTotal += interestEarned + monthlyContribution;
    totalInvested += monthlyContribution;

    // Only store data points periodically to keep chart performant if period is long
    // Or store all if short. For UX, let's store every month but chart might sample later.
    // For simplicity here, we store all.
    breakdown.push({
      month: i,
      year: Math.floor(i / 12),
      invested: parseFloat(totalInvested.toFixed(2)),
      interest: parseFloat((currentTotal - totalInvested).toFixed(2)),
      total: parseFloat(currentTotal.toFixed(2))
    });
  }

  return {
    totalInvested: parseFloat(totalInvested.toFixed(2)),
    totalInterest: parseFloat((currentTotal - totalInvested).toFixed(2)),
    finalAmount: parseFloat(currentTotal.toFixed(2)),
    breakdown
  };
};

export const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};